Minetest 0.4 mod: farming
=========================

License of source code:
-----------------------
Copyright (C) 2012-2013 PilzAdam

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 

License of media (textures):
----------------------------
Created by PilzAdam (License: WTFPL):
  farming_bread.png
  farming_soil.png
  farming_soil_wet.png
  farming_soil_wet_side.png
  farming_string.png

Created by Calinou (License: CC BY-SA):
  farming_tool_bronzehoe.png
  farming_tool_steelhoe.png
  farming_tool_stonehoe.png
  farming_tool_woodhoe.png

Created by VanessaE (License: WTFPL):
  farming_cotton_seed.png
  farming_wheat_seed.png
  farming_flour.png
  farming_wheat.png
  farming_wheat_1.png
  farming_wheat_2.png
  farming_wheat_3.png
  farming_wheat_4.png
  farming_wheat_5.png
  farming_wheat_5.png
  farming_wheat_7.png
  farming_wheat_8.png
  farming_cotton_1.png
  farming_cotton_2.png
  farming_cotton_3.png
  farming_cotton_4.png
  farming_cotton_5.png
  farming_cotton_6.png
  farming_cotton_7.png
  farming_cotton_8.png
