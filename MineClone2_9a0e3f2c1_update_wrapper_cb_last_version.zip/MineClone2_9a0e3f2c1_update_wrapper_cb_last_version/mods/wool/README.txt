Minetest 0.4 mod: wool
======================

Mostly backward-compatible with jordach's 16-color wool mod.

License of source code:
-----------------------
Copyright (C) 2012 Perttu Ahola (celeron55) <celeron55@gmail.com>

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

License of media (textures and sounds)
--------------------------------------
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/

Authors of media files
-----------------------
Cisoun:
- wool_black.png wool_brown.png wool_dark_green.png wool_green.png
- wool_magenta.png wool_pink.png wool_violet.png wool_yellow.png wool_blue.png
- wool_cyan.png wool_dark_grey.png wool_grey.png wool_orange.png wool_red.png
- wool_white.png

